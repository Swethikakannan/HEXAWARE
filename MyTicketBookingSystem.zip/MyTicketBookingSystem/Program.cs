﻿using app;

class Program
{
    static void Main(string[] args)
    {
        TicketBookingSystem system = new TicketBookingSystem();
        system.ShowMenu();
    }
}
