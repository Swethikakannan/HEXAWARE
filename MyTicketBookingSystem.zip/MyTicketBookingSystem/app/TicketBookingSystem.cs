﻿using System;
using System.Collections.Generic;
using bean;
using model;
using service;

namespace app
{
    public class TicketBookingSystem
    {
        private readonly IBookingSystemRepository repo;
        //initializing the constructor
        public TicketBookingSystem()
        {
            repo = new BookingSystemRepositoryImpl();
        }

        public void ShowMenu()
        {
            while (true)
            {
                Console.WriteLine("\n===== Ticket Booking System =====");
                Console.WriteLine("1. Create Event");
                Console.WriteLine("2. View All Events");
                Console.WriteLine("3. Book Tickets");
                Console.WriteLine("4. Cancel Booking");
                Console.WriteLine("5. View Booking Details");
                Console.WriteLine("6. Exit");
                Console.Write("Enter your choice: ");

                switch (Console.ReadLine())
                {
                    case "1":
                        CreateEvent();
                        break;
                    case "2":
                        ViewEvents();
                        break;
                    case "3":
                        BookTickets();
                        break;
                    case "4":
                        CancelBooking();
                        break;
                    case "5":
                        ViewBookingDetails();
                        break;
                    case "6":
                        return;
                    default:
                        Console.WriteLine("Invalid choice.");
                        break;
                }
            }
        }

        // Method to create an event by taking input and calling repo
        private void CreateEvent()
        {
            Console.Write("Enter Event Name: ");
            string name = Console.ReadLine();

            Console.Write("Enter Event Date (yyyy-mm-dd): ");
            DateTime date = DateTime.Parse(Console.ReadLine());

            Console.Write("Enter Event Time (hh:mm:ss): ");
            TimeSpan time = TimeSpan.Parse(Console.ReadLine());

            Console.Write("Enter Venue ID: ");
            int venueId = int.Parse(Console.ReadLine());

            Console.Write("Enter Total Seats: ");
            int total = int.Parse(Console.ReadLine());

            Console.Write("Enter Ticket Price: ");
            decimal price = decimal.Parse(Console.ReadLine());

            Console.Write("Enter Event Type (Movie/Sports/Concert): ");
            string type = Console.ReadLine();

            Event evt = new Event
            {
                Name = name,
                Date = date,
                Time = time,
                Venue = new Venue { Id = venueId },
                TotalSeats = total,
                AvailableSeats = total,
                TicketPrice = price,
                EventType = type
            };

            repo.CreateEvent(evt);
            Console.WriteLine("Event created successfully with ID: " + evt.Id);
        }

        private void ViewEvents()
        {
            List<Event> events = repo.GetEventDetails();
            Console.WriteLine("\n--- Event List ---");
            foreach (var evt in events)
            {
                Console.WriteLine($"ID: {evt.Id}, Name: {evt.Name}, Date: {evt.Date.ToShortDateString()}, Type: {evt.EventType}, Venue: {evt.Venue.Name}, Available: {evt.AvailableSeats}");
            }
        }
        // Method to create an event by taking input and calling repo
        private void BookTickets()
        {
            Console.Write("Enter Event Name: ");
            string eventName = Console.ReadLine();

            Console.Write("Enter number of tickets: ");
            int count = int.Parse(Console.ReadLine());

            // Collect customer details for each ticket
            List<Customer> customers = new List<Customer>();
            for (int i = 1; i <= count; i++)
            {
                Console.WriteLine($"\nCustomer {i}:");
                Console.Write("Name: ");
                string name = Console.ReadLine();
                Console.Write("Email: ");
                string email = Console.ReadLine();
                Console.Write("Phone: ");
                string phone = Console.ReadLine();

                customers.Add(new Customer { Name = name, Email = email, Phone = phone });
            }

            Booking booking = repo.BookTickets(eventName, customers);
            Console.WriteLine($"Booking successful! Booking ID: {booking.Id}");
        }
        // Method to cancel a booking
        private void CancelBooking()
        {
            Console.Write("Enter Booking ID to cancel: ");
            int id = int.Parse(Console.ReadLine());

            bool success = repo.CancelBooking(id);
            Console.WriteLine(success ? "Booking cancelled." : "Booking not found.");
        }
        // Method to view details of a booking
        private void ViewBookingDetails()
        {
            Console.Write("Enter Booking ID: ");
            int id = int.Parse(Console.ReadLine());

            Booking booking = repo.GetBookingDetails(id);
            if (booking != null)
            {
                Console.WriteLine($"Booking ID: {booking.Id}, Event: {booking.EventName}, Date: {booking.BookingDate}, Total: ₹{booking.TotalCost}");
                Console.WriteLine("Customers:");
                foreach (var cust in booking.Customers)
                {
                    Console.WriteLine($" - {cust.Name}, {cust.Email}, {cust.Phone}");
                }
            }
            else
            {
                Console.WriteLine("Booking not found.");
            }
        }
    }
}

