﻿namespace model
{
    public class Venue
    {
        public int Id { get; set; } // venue_id
        public string Name { get; set; } // venue_name
        public string Address { get; set; } // address
    }
}

