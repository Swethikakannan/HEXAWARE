﻿using System;
using System.Collections.Generic;

namespace model
{
    public class Booking
    {
        public int Id { get; set; } // booking_id
        public string EventName { get; set; } // Event_Name
        public DateTime BookingDate { get; set; }
        public int NumTickets { get; set; }
        public decimal TotalCost { get; set; }
        public List<Customer> Customers { get; set; }
    }
}
