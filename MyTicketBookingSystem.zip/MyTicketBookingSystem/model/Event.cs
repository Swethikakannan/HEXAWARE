﻿using System;

namespace model
{
    public class Event
    {
        public int Id { get; set; } // event_id
        public string Name { get; set; } // event_name
        public DateTime Date { get; set; } // event_date
        public TimeSpan Time { get; set; } // event_time
        public Venue Venue { get; set; } // venue_id (FK)
        public int TotalSeats { get; set; }
        public int AvailableSeats { get; set; }
        public decimal TicketPrice { get; set; }
        public string EventType { get; set; } // Movie, Sports, Concert
    }

    public class Movie : Event { }
    public class Sports : Event { }
    public class Concert : Event { }
}
