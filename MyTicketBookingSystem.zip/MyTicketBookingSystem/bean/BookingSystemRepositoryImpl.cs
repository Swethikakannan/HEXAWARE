﻿//Please Install MicroSoft SqlClient package 
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using model;
using service;
using exception; 

namespace bean
{
    public class BookingSystemRepositoryImpl : IBookingSystemRepository
    {
        private string connStr = "Server=LAPTOP-MLLR0EGE;Database=TicketBookingSystem;Trusted_Connection=True;Encrypt=False;";

        // 1. INSERT Event into DB and return created Event with new ID
        public Event CreateEvent(Event evt)
        {
            using SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            string query = @"INSERT INTO Event (event_name, event_date, event_time, venue_id, total_seats, available_seats, ticket_price, event_type)
                             VALUES (@name, @date, @time, @venueId, @total, @available, @price, @type);
                             SELECT SCOPE_IDENTITY();";

            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@name", evt.Name);
            cmd.Parameters.AddWithValue("@date", evt.Date);
            cmd.Parameters.AddWithValue("@time", evt.Time);
            cmd.Parameters.AddWithValue("@venueId", evt.Venue.Id);
            cmd.Parameters.AddWithValue("@total", evt.TotalSeats);
            cmd.Parameters.AddWithValue("@available", evt.AvailableSeats);
            cmd.Parameters.AddWithValue("@price", evt.TicketPrice);
            cmd.Parameters.AddWithValue("@type", evt.EventType);

            object result = cmd.ExecuteScalar();
            if (result == null || result == DBNull.Value)
                throw new Exception("Failed to insert event.");

            evt.Id = Convert.ToInt32(result);
            return evt;
        }

        // 2. SELECT all events with JOIN on Venue to show location info
        public List<Event> GetEventDetails()
        {
            List<Event> events = new List<Event>();
            using SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            string query = @"SELECT e.*, v.venue_id, v.venue_name, v.address
                             FROM Event e JOIN Venue v ON e.venue_id = v.venue_id";

            SqlCommand cmd = new SqlCommand(query, conn);
            using SqlDataReader reader = cmd.ExecuteReader();

            while (reader.Read())
            {
                Venue venue = new Venue
                {
                    Id = (int)reader["venue_id"],
                    Name = (string)reader["venue_name"],
                    Address = (string)reader["address"]
                };

                Event evt = new Event
                {
                    Id = (int)reader["event_id"],
                    Name = (string)reader["event_name"],
                    Date = (DateTime)reader["event_date"],
                    Time = (TimeSpan)reader["event_time"],
                    Venue = venue,
                    TotalSeats = (int)reader["total_seats"],
                    AvailableSeats = (int)reader["available_seats"],
                    TicketPrice = (decimal)reader["ticket_price"],
                    EventType = (string)reader["event_type"]
                };

                events.Add(evt);
            }

            return events;
        }

        // 3. SELECT available seats from Event table
        public int GetAvailableNoOfTickets(string eventName)
        {
            using SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            string query = "SELECT available_seats FROM Event WHERE event_name = @name";
            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@name", eventName);

            return (int?)cmd.ExecuteScalar() ?? 0;
        }

        // 4. INSERT booking and customer, UPDATE available seats (uses TRANSACTION)
        public Booking BookTickets(string eventName, List<Customer> customers)
        {
            using SqlConnection conn = new SqlConnection(connStr);
            conn.Open();
            SqlTransaction tx = conn.BeginTransaction();

            try
            {
                // Step 1: Get event details
                string eventQuery = "SELECT event_id, ticket_price, available_seats FROM Event WHERE event_name = @name";
                int eventId = 0, available = 0;
                decimal price = 0m;

                using (SqlCommand eventCmd = new SqlCommand(eventQuery, conn, tx))
                {
                    eventCmd.Parameters.AddWithValue("@name", eventName);
                    using SqlDataReader reader = eventCmd.ExecuteReader();

                    if (reader.Read())
                    {
                        eventId = (int)reader["event_id"];
                        price = (decimal)reader["ticket_price"];
                        available = (int)reader["available_seats"];
                    }
                    else
                    {
                        throw new EventNotFoundException($"Event '{eventName}' not found.");
                    }
                } //  Reader is now closed

                if (available < customers.Count)
                    throw new Exception("Not enough tickets available!");

                // Step 2: Insert booking
                string bookingQuery = @"INSERT INTO Booking (event_id, num_tickets, total_cost, booking_date)
                                        VALUES (@eid, @num, @cost, @date);
                                        SELECT SCOPE_IDENTITY();";

                SqlCommand bookCmd = new SqlCommand(bookingQuery, conn, tx);
                bookCmd.Parameters.AddWithValue("@eid", eventId);
                bookCmd.Parameters.AddWithValue("@num", customers.Count);
                bookCmd.Parameters.AddWithValue("@cost", customers.Count * price);
                bookCmd.Parameters.AddWithValue("@date", DateTime.Now);

                int bookingId = Convert.ToInt32(bookCmd.ExecuteScalar());

                // Step 3: Insert customers
                foreach (var cust in customers)
                {
                    string custInsert = @"INSERT INTO Customer (customer_name, email, phone_number, booking_id)
                                          VALUES (@name, @email, @phone, @bid)";
                    SqlCommand custCmd = new SqlCommand(custInsert, conn, tx);
                    custCmd.Parameters.AddWithValue("@name", cust.Name);
                    custCmd.Parameters.AddWithValue("@email", cust.Email);
                    custCmd.Parameters.AddWithValue("@phone", cust.Phone);
                    custCmd.Parameters.AddWithValue("@bid", bookingId);
                    //custCmd.ExecuteNonQuery();
                }

                // Step 4: Update available seats
                string updateSeats = "UPDATE Event SET available_seats = available_seats - @count WHERE event_id = @eid";
                SqlCommand updateCmd = new SqlCommand(updateSeats, conn, tx);
                updateCmd.Parameters.AddWithValue("@count", customers.Count);
                updateCmd.Parameters.AddWithValue("@eid", eventId);
                updateCmd.ExecuteNonQuery();

                tx.Commit();

                return new Booking
                {
                    Id = bookingId,
                    EventName = eventName,
                    BookingDate = DateTime.Now,
                    NumTickets = customers.Count,
                    TotalCost = price * customers.Count,
                    Customers = customers
                };
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        // 5. DELETE booking and UPDATE seat count
        public bool CancelBooking(int bookingId)
        {
            using SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            string getEventId = "SELECT event_id, num_tickets FROM Booking WHERE booking_id = @bid";
            SqlCommand getCmd = new SqlCommand(getEventId, conn);
            getCmd.Parameters.AddWithValue("@bid", bookingId);

            int eventId = 0, num = 0;

            using (SqlDataReader reader = getCmd.ExecuteReader())
            {
                if (reader.Read())
                {
                    eventId = (int)reader["event_id"];
                    num = (int)reader["num_tickets"];
                }
                else
                {
                    throw new Exception("Invalid booking ID!");
                }
            }

            string update = "UPDATE Event SET available_seats = available_seats + @num WHERE event_id = @eid";
            SqlCommand updateCmd = new SqlCommand(update, conn);
            updateCmd.Parameters.AddWithValue("@num", num);
            updateCmd.Parameters.AddWithValue("@eid", eventId);
            updateCmd.ExecuteNonQuery();

            string delete = "DELETE FROM Booking WHERE booking_id = @bid";
            SqlCommand deleteCmd = new SqlCommand(delete, conn);
            deleteCmd.Parameters.AddWithValue("@bid", bookingId);
            deleteCmd.ExecuteNonQuery();

            return true;
        }

        // 6. SELECT Booking + Customer + Event details using JOINs
        public Booking GetBookingDetails(int bookingId)
        {
            using SqlConnection conn = new SqlConnection(connStr);
            conn.Open();

            string query = @"SELECT b.booking_id, b.booking_date, b.num_tickets, b.total_cost, e.event_name,
                                    c.customer_id, c.customer_name, c.email, c.phone_number
                             FROM Booking b
                             JOIN Event e ON b.event_id = e.event_id
                             JOIN Customer c ON b.booking_id = c.booking_id
                             WHERE b.booking_id = @bid";

            SqlCommand cmd = new SqlCommand(query, conn);
            cmd.Parameters.AddWithValue("@bid", bookingId);

            Booking booking = null;
            List<Customer> customers = new List<Customer>();

            using (SqlDataReader reader = cmd.ExecuteReader())
            {
                while (reader.Read())
                {
                    if (booking == null)
                    {
                        booking = new Booking
                        {
                            Id = Convert.ToInt32(reader["booking_id"]),
                            BookingDate = Convert.ToDateTime(reader["booking_date"]),
                            NumTickets = Convert.ToInt32(reader["num_tickets"]),
                            TotalCost = Convert.ToDecimal(reader["total_cost"]),
                            EventName = reader["event_name"].ToString(),
                            Customers = new List<Customer>()
                        };
                    }

                    Customer cust = new Customer
                    {
                        Id = Convert.ToInt32(reader["customer_id"]),
                        Name = reader["customer_name"].ToString(),
                        Email = reader["email"].ToString(),
                        Phone = reader["phone_number"].ToString()
                    };
                    booking.Customers.Add(cust);
                }
            }

            return booking;
        }
    }
}



//// bean/BookingSystemRepositoryImpl.cs
//using Microsoft.Data.SqlClient;
//using System;
//using System.Collections.Generic;
//using model;
//using service;
//using exception;

//namespace bean
//{
//    public class BookingSystemRepositoryImpl : IBookingSystemRepository
//    {
//        // Connection string to your SQL Server database
//        private readonly string connStr = "Server=LAPTOP-MLLR0EGE;Database=TicketBookingSystem;Trusted_Connection=True;Encrypt=False;";

//        // Create a new event and store it in DB
//        public Event CreateEvent(Event evt)
//        {
//            using var conn = new SqlConnection(connStr);
//            conn.Open();

//            string query = @"
//                INSERT INTO Event (event_name, event_date, event_time, venue_id, total_seats, available_seats, ticket_price, event_type)
//                VALUES (@name, @date, @time, @venueId, @totalSeats, @availableSeats, @price, @type);
//                SELECT SCOPE_IDENTITY();";

//            using var cmd = new SqlCommand(query, conn);
//            cmd.Parameters.AddWithValue("@name", evt.Name);
//            cmd.Parameters.AddWithValue("@date", evt.Date);
//            cmd.Parameters.AddWithValue("@time", evt.Time);
//            cmd.Parameters.AddWithValue("@venueId", evt.Venue.Id);
//            cmd.Parameters.AddWithValue("@totalSeats", evt.TotalSeats);
//            cmd.Parameters.AddWithValue("@availableSeats", evt.AvailableSeats);
//            cmd.Parameters.AddWithValue("@price", evt.TicketPrice);
//            cmd.Parameters.AddWithValue("@type", evt.EventType);

//            object result = cmd.ExecuteScalar();
//            Console.WriteLine("SCOPE_IDENTITY() returned: " + result);

//            evt.Id = Convert.ToInt32(result); 

//            //evt.Id = Convert.ToInt32(cmd.ExecuteScalar());
//            return evt;
//        }

//        // Retrieve all events with venue info
//        public List<Event> GetEventDetails()
//        {
//            var events = new List<Event>();
//            using var conn = new SqlConnection(connStr);
//            conn.Open();

//            string query = @"
//                SELECT e.*, v.venue_id, v.venue_name, v.address
//                FROM Event e
//                JOIN Venue v ON e.venue_id = v.venue_id;";

//            using var cmd = new SqlCommand(query, conn);
//            using var reader = cmd.ExecuteReader();

//            while (reader.Read())
//            {
//                var venue = new Venue
//                {
//                    Id = (int)reader["venue_id"],
//                    Name = (string)reader["venue_name"],
//                    Address = (string)reader["address"]
//                };

//                var evt = new Event
//                {
//                    Id = (int)reader["event_id"],
//                    Name = (string)reader["event_name"],
//                    Date = (DateTime)reader["event_date"],
//                    Time = (TimeSpan)reader["event_time"],
//                    Venue = venue,
//                    TotalSeats = (int)reader["total_seats"],
//                    AvailableSeats = (int)reader["available_seats"],
//                    TicketPrice = (decimal)reader["ticket_price"],
//                    EventType = (string)reader["event_type"]
//                };

//                events.Add(evt);
//            }

//            return events;
//        }

//        // Get how many seats are available for a specific event
//        public int GetAvailableNoOfTickets(string eventName)
//        {
//            using var conn = new SqlConnection(connStr);
//            conn.Open();

//            string query = "SELECT available_seats FROM Event WHERE event_name = @name;";
//            using var cmd = new SqlCommand(query, conn);
//            cmd.Parameters.AddWithValue("@name", eventName);

//            return (int?)cmd.ExecuteScalar() ?? 0;
//        }

//        // Book tickets: insert booking, customers; update seats; inside a transaction
//        public Booking BookTickets(string eventName, List<Customer> customers)
//        {
//            using var conn = new SqlConnection(connStr);
//            conn.Open();
//            using var tx = conn.BeginTransaction();

//            try
//            {
//                // Fetch event details
//                string eventQuery = "SELECT event_id, ticket_price, available_seats FROM Event WHERE event_name = @name;";
//                using var eventCmd = new SqlCommand(eventQuery, conn, tx);
//                eventCmd.Parameters.AddWithValue("@name", eventName);

//                int eventId = 0;
//                decimal price = 0m;
//                int available = 0;

//                using var reader = eventCmd.ExecuteReader();
//                if (reader.Read())
//                {
//                    eventId = (int)reader["event_id"];
//                    price = (decimal)reader["ticket_price"];
//                    available = (int)reader["available_seats"];
//                }
//                else
//                {
//                    throw new EventNotFoundException($"Event '{eventName}' not found.");
//                }

//                if (available < customers.Count)
//                {
//                    throw new EventNotFoundException($"Not enough tickets available for '{eventName}'. Requested: {customers.Count}, Available: {available}.");
//                }

//                // Insert booking
//                string bookingQuery = @"
//                    INSERT INTO Booking (event_id, num_tickets, total_cost, booking_date)
//                    VALUES (@eid, @num, @cost, @date);
//                    SELECT SCOPE_IDENTITY();";
//                using var bookCmd = new SqlCommand(bookingQuery, conn, tx);
//                bookCmd.Parameters.AddWithValue("@eid", eventId);
//                bookCmd.Parameters.AddWithValue("@num", customers.Count);
//                bookCmd.Parameters.AddWithValue("@cost", customers.Count * price);
//                bookCmd.Parameters.AddWithValue("@date", DateTime.Now);

//                int bookingId = Convert.ToInt32(bookCmd.ExecuteScalar()); 

//                // Insert each customer and link to booking
//                foreach (var cust in customers)
//                {
//                    string custQuery = @"
//                        INSERT INTO Customer (customer_name, email, phone_number, booking_id)
//                        VALUES (@cname, @email, @phone, @bid);";
//                    using var custCmd = new SqlCommand(custQuery, conn, tx);
//                    custCmd.Parameters.AddWithValue("@cname", cust.Name);
//                    custCmd.Parameters.AddWithValue("@email", cust.Email);
//                    custCmd.Parameters.AddWithValue("@phone", cust.Phone);
//                    custCmd.Parameters.AddWithValue("@bid", bookingId);
//                    custCmd.ExecuteNonQuery();
//                }

//                // Update seats
//                string updateSeats = "UPDATE Event SET available_seats = available_seats - @cnt WHERE event_id = @eid;";
//                using var updateCmd = new SqlCommand(updateSeats, conn, tx);
//                updateCmd.Parameters.AddWithValue("@cnt", customers.Count);
//                updateCmd.Parameters.AddWithValue("@eid", eventId);
//                updateCmd.ExecuteNonQuery();

//                tx.Commit();

//                return new Booking
//                {
//                    Id = bookingId,
//                    EventName = eventName,
//                    BookingDate = DateTime.Now,
//                    NumTickets = customers.Count,
//                    TotalCost = price * customers.Count,
//                    Customers = customers
//                };
//            }
//            catch
//            {
//                tx.Rollback();
//                throw;
//            }
//        }

//        // Cancel booking: validates booking, updates seats, deletes booking and related customers
//        public bool CancelBooking(int bookingId)
//        {
//            using var conn = new SqlConnection(connStr);
//            conn.Open();
//            using var tx = conn.BeginTransaction();

//            try
//            {
//                string fetch = "SELECT event_id, num_tickets FROM Booking WHERE booking_id = @bid;";
//                using var fetchCmd = new SqlCommand(fetch, conn, tx);
//                fetchCmd.Parameters.AddWithValue("@bid", bookingId);

//                int eventId = 0, num = 0;
//                using (var reader = fetchCmd.ExecuteReader())
//                {
//                    if (reader.Read())
//                    {
//                        eventId = (int)reader["event_id"];
//                        num = (int)reader["num_tickets"];
//                    }
//                    else
//                    {
//                        throw new InvalidBookingIdException($"Booking ID '{bookingId}' not found.");
//                    }
//                }

//                // Delete customers first (child records)
//                string deleteCust = "DELETE FROM Customer WHERE booking_id = @bid;";
//                using var delCustCmd = new SqlCommand(deleteCust, conn, tx);
//                delCustCmd.Parameters.AddWithValue("@bid", bookingId);
//                delCustCmd.ExecuteNonQuery();

//                // Delete booking
//                string deleteBook = "DELETE FROM Booking WHERE booking_id = @bid;";
//                using var delBookCmd = new SqlCommand(deleteBook, conn, tx);
//                delBookCmd.Parameters.AddWithValue("@bid", bookingId);
//                delBookCmd.ExecuteNonQuery();

//                // Update the seats back
//                string updateEvent = "UPDATE Event SET available_seats = available_seats + @num WHERE event_id = @eid;";
//                using var upCmd = new SqlCommand(updateEvent, conn, tx);
//                upCmd.Parameters.AddWithValue("@num", num);
//                upCmd.Parameters.AddWithValue("@eid", eventId);
//                upCmd.ExecuteNonQuery();

//                tx.Commit();
//                return true;
//            }
//            catch
//            {
//                tx.Rollback();
//                throw;
//            }
//        }

//        // Retrieve booking details with customer list
//        public Booking GetBookingDetails(int bookingId)
//        {
//            using var conn = new SqlConnection(connStr);
//            conn.Open();

//            string query = @"
//                SELECT b.booking_id, b.booking_date, b.num_tickets, b.total_cost, e.event_name,
//                       c.customer_id, c.customer_name, c.email, c.phone_number
//                FROM Booking b
//                JOIN Event e ON b.event_id = e.event_id
//                JOIN Customer c ON b.booking_id = c.booking_id
//                WHERE b.booking_id = @bid;";
//            using var cmd = new SqlCommand(query, conn);
//            cmd.Parameters.AddWithValue("@bid", bookingId);

//            Booking booking = null;
//            var customers = new List<Customer>();

//            using var reader = cmd.ExecuteReader();
//            while (reader.Read())
//            {
//                if (booking == null)
//                {
//                    booking = new Booking
//                    {
//                        Id = (int)reader["booking_id"],
//                        BookingDate = (DateTime)reader["booking_date"],
//                        NumTickets = (int)reader["num_tickets"],
//                        TotalCost = (decimal)reader["total_cost"],
//                        EventName = (string)reader["event_name"],
//                        Customers = new List<Customer>()
//                    };
//                }

//                var cust = new Customer
//                {
//                    Id = (int)reader["customer_id"],
//                    Name = (string)reader["customer_name"],
//                    Email = (string)reader["email"],
//                    Phone = (string)reader["phone_number"]
//                };
//                booking.Customers.Add(cust);
//            }

//            if (booking == null)
//                throw new InvalidBookingIdException($"Booking ID '{bookingId}' not found.");

//            return booking;
//        }
//    }
//}



