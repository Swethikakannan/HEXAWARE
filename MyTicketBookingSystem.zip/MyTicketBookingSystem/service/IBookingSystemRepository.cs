﻿using System.Collections.Generic;
using model;

namespace service
{
    public interface IBookingSystemRepository
    {
        Event CreateEvent(Event evt);
        List<Event> GetEventDetails();
        int GetAvailableNoOfTickets(string eventName);
        Booking BookTickets(string eventName, List<Customer> customers);
        bool CancelBooking(int bookingId);
        Booking GetBookingDetails(int bookingId);
    }
}
