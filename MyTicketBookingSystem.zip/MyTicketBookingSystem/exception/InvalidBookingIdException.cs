﻿
using System;

namespace exception
{
    public class InvalidBookingIdException : Exception
    {
        public InvalidBookingIdException() { }
        public InvalidBookingIdException(string message) : base(message) { }
        public InvalidBookingIdException(string message, Exception inner) : base(message, inner) { }
    }
}