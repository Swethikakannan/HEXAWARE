﻿using System;
using System.Data.SqlClient;
using System.IO;

namespace HospitalManagementSystem.util
{
    public class DBConnUtil
    {
        private static SqlConnection connection;

        public static SqlConnection GetConnection()
        {
            if (connection == null || connection.State == System.Data.ConnectionState.Closed)
            {
                string filePath = "db.properties";

                if (!File.Exists(filePath))
                {
                    Console.WriteLine("Connection file not found: " + filePath);
                    return null;
                }

                string connStr = PropertyUtil.GetPropertyString(filePath);

                if (!string.IsNullOrEmpty(connStr))
                {
                    connection = new SqlConnection(connStr);
                    connection.Open();
                }
                else
                {
                    Console.WriteLine("Failed to read connection string.");
                }
            }

            return connection;
        }
    }
}

