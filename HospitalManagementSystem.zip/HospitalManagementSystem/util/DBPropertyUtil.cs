﻿using System;
using System.Collections.Generic;
using System.IO;

namespace HospitalManagementSystem.util
{
    public class PropertyUtil
    {
        public static string GetPropertyString(string filePath)
        {
            Dictionary<string, string> props = new Dictionary<string, string>();

            try
            {
                foreach (string line in File.ReadAllLines(filePath))
                {
                    if (!string.IsNullOrWhiteSpace(line) && line.Contains("="))
                    {
                        string[] parts = line.Split('=');
                        if (parts.Length == 2)
                            props[parts[0].Trim()] = parts[1].Trim();
                    }
                }

                // Check if using trusted connection
                if (props.ContainsKey("trusted_connection") && props["trusted_connection"].ToLower() == "true")
                {
                    return $"Server={props["server"]};Database={props["database"]};Trusted_Connection=True;";
                }
                else
                {
                    return $"Server={props["server"]};Database={props["database"]};User Id={props["username"]};Password={props["password"]};";
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error reading property file: " + ex.Message);
                return null;
            }
        }
    }
}
