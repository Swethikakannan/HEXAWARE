﻿


using HospitalManagementSystem.entity;
using HospitalManagementSystem.util;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Net.NetworkInformation;


namespace HospitalManagementSystem.dao
{
    public class HospitalServiceImpl : IHospitalService
    {
        private readonly SqlConnection connection;

        public HospitalServiceImpl()
        {
            connection = DBConnUtil.GetConnection();
        }

        public Appointment GetAppointmentById(int appointmentId)
        {
            Appointment appointment = null;

            string query = "SELECT * FROM Appointment WHERE appointmentId = @appointmentId";

            using (SqlCommand cmd = new SqlCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@appointmentId", appointmentId);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        appointment = new Appointment(
                            Convert.ToInt32(reader["appointmentId"]),
                            Convert.ToInt32(reader["patientId"]),
                            Convert.ToInt32(reader["doctorId"]),
                            Convert.ToDateTime(reader["appointmentDate"]),
                            reader["description"].ToString()
                        );
                    }
                }
            }

            return appointment;
        }

        public List<Appointment> GetAppointmentsForPatient(int patientId)
        {
            List<Appointment> appointments = new List<Appointment>();
            string query = "SELECT * FROM Appointment WHERE patientId = @patientId";

            using (SqlCommand cmd = new SqlCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@patientId", patientId);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        appointments.Add(new Appointment(
                            Convert.ToInt32(reader["appointmentId"]),
                            Convert.ToInt32(reader["patientId"]),
                            Convert.ToInt32(reader["doctorId"]),
                            Convert.ToDateTime(reader["appointmentDate"]),
                            reader["description"].ToString()
                        ));
                    }
                }
            }

            return appointments;
        }

        public List<Appointment> GetAppointmentsForDoctor(int doctorId)
        {
            List<Appointment> appointments = new List<Appointment>();
            string query = "SELECT * FROM Appointment WHERE doctorId = @doctorId";

            using (SqlCommand cmd = new SqlCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@doctorId", doctorId);

                using (SqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        appointments.Add(new Appointment(
                            Convert.ToInt32(reader["appointmentId"]),
                            Convert.ToInt32(reader["patientId"]),
                            Convert.ToInt32(reader["doctorId"]),
                            Convert.ToDateTime(reader["appointmentDate"]),
                            reader["description"].ToString()
                        ));
                    }
                }
            }

            return appointments;
        }

        public bool ScheduleAppointment(Appointment appointment)
        {
            string query = @"INSERT INTO Appointment (patientId, doctorId, appointmentDate, description)
                             VALUES (@patientId, @doctorId, @appointmentDate, @description)";

            using (SqlCommand cmd = new SqlCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@patientId", appointment.PatientId);
                cmd.Parameters.AddWithValue("@doctorId", appointment.DoctorId);
                cmd.Parameters.AddWithValue("@appointmentDate", appointment.AppointmentDate);
                cmd.Parameters.AddWithValue("@description", appointment.Description);

                int rowsAffected = cmd.ExecuteNonQuery();
                return rowsAffected > 0;

            }
        }


        public bool UpdateAppointment(Appointment appointment)
        {
            string query = @"UPDATE Appointment
                             SET patientId = @patientId,
                                 doctorId = @doctorId,
                                 appointmentDate = @appointmentDate,
                                 description = @description
                             WHERE appointmentId = @appointmentId";

            using (SqlCommand cmd = new SqlCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@appointmentId", appointment.AppointmentId);
                cmd.Parameters.AddWithValue("@patientId", appointment.PatientId);
                cmd.Parameters.AddWithValue("@doctorId", appointment.DoctorId);
                cmd.Parameters.AddWithValue("@appointmentDate", appointment.AppointmentDate);
                cmd.Parameters.AddWithValue("@description", appointment.Description);

                int rowsAffected = cmd.ExecuteNonQuery();
                return rowsAffected > 0;
            }
        }

        public bool CancelAppointment(int appointmentId)
        {
            string query = "DELETE FROM dbo.Appointment WHERE appointmentId = @appointmentId";

            using (SqlCommand cmd = new SqlCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("@appointmentId", appointmentId);

                int rowsAffected = cmd.ExecuteNonQuery();
                return rowsAffected > 0;
            }
        }
    }
}
