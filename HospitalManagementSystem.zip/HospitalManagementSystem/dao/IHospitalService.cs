﻿//using System.Collections.Generic;
//using HospitalManagementSystem.entity;

//namespace HospitalManagementSystem.dao
//{
//    public interface IHospitalService
//    {
//        // a. Get Appointment by ID
//        Appointment getAppointmentById(int appointmentId);

//        // b. Get all Appointments for a Patient
//        List<Appointment> getAppointmentsForPatient(int patientId);

//        // c. Get all Appointments for a Doctor
//        List<Appointment> getAppointmentsForDoctor(int doctorId);

//        // d. Schedule a new Appointment
//        bool scheduleAppointment(Appointment appointment);

//        // e. Update an existing Appointment
//        bool updateAppointment(Appointment appointment);

//        // f. Cancel an Appointment by ID
//        bool cancelAppointment(int appointmentId);
//    }
//}


using System.Collections.Generic;
using HospitalManagementSystem.entity;

namespace HospitalManagementSystem.dao
{
    public interface IHospitalService
    {
        Appointment GetAppointmentById(int appointmentId);
        List<Appointment> GetAppointmentsForPatient(int patientId);
        List<Appointment> GetAppointmentsForDoctor(int doctorId);
        bool ScheduleAppointment(Appointment appointment);
        bool UpdateAppointment(Appointment appointment);
        bool CancelAppointment(int appointmentId);
    }
}

