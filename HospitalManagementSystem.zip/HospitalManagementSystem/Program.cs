﻿using System;
using HospitalManagementSystem.main;

namespace HospitalManagementSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            MainModule.ShowMenu(); 
        }

    }
}

