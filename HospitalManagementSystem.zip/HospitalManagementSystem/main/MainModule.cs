﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using HospitalManagementSystem.dao;
using HospitalManagementSystem.entity;
using HospitalManagementSystem.exception;

namespace HospitalManagementSystem.main
{
    public class MainModule
    {
        public static void ShowMenu()
        {
            IHospitalService service = new HospitalServiceImpl();
            bool exit = false;

            while (!exit)
            {
                Console.WriteLine("\n===== Hospital Management System =====");
                Console.WriteLine("1. Schedule Appointment");
                Console.WriteLine("2. Update Appointment");
                Console.WriteLine("3. Cancel Appointment");
                Console.WriteLine("4. Get Appointment By ID");
                Console.WriteLine("5. Get Appointments for Patient");
                Console.WriteLine("6. Get Appointments for Doctor");
                Console.WriteLine("7. Exit");
                Console.Write("Enter your choice: ");

                string choice = Console.ReadLine();
                switch (choice)
                {
                    case "1":
                        ScheduleAppointment(service);
                        break;
                    case "2":
                        UpdateAppointment(service);
                        break;
                    case "3":
                        CancelAppointment(service);
                        break;
                    case "4":
                        GetAppointmentById(service);
                        break;
                    case "5":
                        GetAppointmentsForPatient(service);
                        break;
                    case "6":
                        GetAppointmentsForDoctor(service);
                        break;
                    case "7":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Invalid choice!");
                        break;
                }
            }
        }

        private static void ScheduleAppointment(IHospitalService service)
        {
            Console.Write("Enter Patient ID: ");
            int pid = int.Parse(Console.ReadLine());

            Console.Write("Enter Doctor ID: ");
            int did = int.Parse(Console.ReadLine());

            Console.Write("Enter Appointment Date (yyyy-mm-dd): ");
            DateTime date = DateTime.Parse(Console.ReadLine());

            Console.Write("Enter Description: ");
            string desc = Console.ReadLine();

            Appointment appt = new Appointment(0, pid, did, date, desc);

            try
            {
                bool result = service.ScheduleAppointment(appt);
                Console.WriteLine(result ? "Appointment Scheduled!" : "Failed to schedule.");
            }
            catch (SqlException ex)
            {
                Console.WriteLine("ERROR: Make sure the Patient ID and Doctor ID exist.");
            }
        }

        private static void UpdateAppointment(IHospitalService service)
        {
            Console.Write("Enter Appointment ID to Update: ");
            int id = int.Parse(Console.ReadLine());

            Console.Write("Enter New Patient ID: ");
            int pid = int.Parse(Console.ReadLine());

            Console.Write("Enter New Doctor ID: ");
            int did = int.Parse(Console.ReadLine());

            Console.Write("Enter New Appointment Date (yyyy-mm-dd): ");
            DateTime date = DateTime.Parse(Console.ReadLine());

            Console.Write("Enter New Description: ");
            string desc = Console.ReadLine();

            Appointment updated = new Appointment(id, pid, did, date, desc);

            try
            {
                bool result = service.UpdateAppointment(updated);
                Console.WriteLine(result ? "Appointment Updated!" : "Update Failed.");
            }
            catch (SqlException ex)
            {
                Console.WriteLine("ERROR: PatientId or DoctorId may not exist in DB.");
            }
        }

        private static void CancelAppointment(IHospitalService service)
        {
            Console.Write("Enter Appointment ID to cancel: ");
            int id = int.Parse(Console.ReadLine());

            bool result = service.CancelAppointment(id);
            Console.WriteLine(result ? "Appointment Cancelled." : "Cancel failed.");
        }

        private static void GetAppointmentById(IHospitalService service)
        {
            Console.Write("Enter Appointment ID: ");
            int id = int.Parse(Console.ReadLine());

            try
            {
                Appointment appt = service.GetAppointmentById(id);
                Console.WriteLine(appt);
            }
            catch (AppointmentNotFoundException ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }

        private static void GetAppointmentsForPatient(IHospitalService service)
        {
            Console.Write("Enter Patient ID: ");
            int pid = int.Parse(Console.ReadLine());

            List<Appointment> list = service.GetAppointmentsForPatient(pid);
            foreach (var a in list)
                Console.WriteLine(a);
        }

        private static void GetAppointmentsForDoctor(IHospitalService service)
        {
            Console.Write("Enter Doctor ID: ");
            int did = int.Parse(Console.ReadLine());

            List<Appointment> list = service.GetAppointmentsForDoctor(did);
            foreach (var a in list)
                Console.WriteLine(a);
        }
    }
}



//using HospitalManagementSystem.dao;
//using HospitalManagementSystem.entity;
//using HospitalManagementSystem.exception;
//using HospitalManagementSystem.main;
//using System;
//using System.Collections.Generic;

//namespace HospitalManagementSystem.main
//{
//    public class MainModule
//    {
//        public static void ShowMenu()
//        {
//            IHospitalService service = new HospitalServiceImpl();
//            bool exit = false;

//            while (!exit)
//            {
//                Console.WriteLine("\n===== Hospital Management System =====");
//                Console.WriteLine("1. Schedule Appointment");
//                Console.WriteLine("2. Update Appointment");
//                Console.WriteLine("3. Cancel Appointment");
//                Console.WriteLine("4. Get Appointment By ID");
//                Console.WriteLine("5. Get Appointments for Patient");
//                Console.WriteLine("6. Get Appointments for Doctor");
//                Console.WriteLine("7. Exit");
//                Console.Write("Enter your choice: ");

//                string choice = Console.ReadLine();
//                switch (choice)
//                {
//                    case "1":
//                        ScheduleAppointment(service);
//                        break;
//                    case "2":
//                        UpdateAppointment(service);
//                        break;
//                    case "3":
//                        CancelAppointment(service);
//                        break;
//                    case "4":
//                        GetAppointmentById(service);
//                        break;
//                    case "5":
//                        GetAppointmentsForPatient(service);
//                        break;
//                    case "6":
//                        GetAppointmentsForDoctor(service);
//                        break;
//                    case "7":
//                        exit = true;
//                        break;
//                    default:
//                        Console.WriteLine("Invalid choice!");
//                        break;
//                }
//            }
//        }

//        private static void ScheduleAppointment(IHospitalService service)
//        {
//            Console.Write("Enter Patient ID: ");
//            int pid = int.Parse(Console.ReadLine());

//            Console.Write("Enter Doctor ID: ");
//            int did = int.Parse(Console.ReadLine());

//            Console.Write("Enter Appointment Date (yyyy-mm-dd): ");
//            DateTime date = DateTime.Parse(Console.ReadLine());

//            Console.Write("Enter Description: ");
//            string desc = Console.ReadLine();

//            Appointment appt = new Appointment
//            {
//                PatientId = pid,
//                DoctorId = did,
//                AppointmentDate = date,
//                Description = desc
//            };

//            bool result = service.ScheduleAppointment(appt);
//            Console.WriteLine(result ? "Appointment Scheduled!" : "Failed to schedule.");
//        }

//        private static void UpdateAppointment(IHospitalService service)
//        {
//            Console.Write("Enter Appointment ID to Update: ");
//            int id = int.Parse(Console.ReadLine());

//            Console.Write("Enter New Patient ID: ");
//            int pid = int.Parse(Console.ReadLine());

//            Console.Write("Enter New Doctor ID: ");
//            int did = int.Parse(Console.ReadLine());

//            Console.Write("Enter New Date (yyyy-mm-dd): ");
//            DateTime date = DateTime.Parse(Console.ReadLine());

//            Console.Write("Enter New Description: ");
//            string desc = Console.ReadLine();

//            Appointment appt = new Appointment(id, pid, did, date, desc);
//            bool result = service.UpdateAppointment(appt);
//            Console.WriteLine(result ? "Appointment Updated!" : "Update Failed.");
//        }

//        private static void CancelAppointment(IHospitalService service)
//        {
//            Console.Write("Enter Appointment ID to cancel: ");
//            int id = int.Parse(Console.ReadLine());

//            bool result = service.CancelAppointment(id);
//            Console.WriteLine(result ? "Appointment Cancelled." : "Cancel failed.");
//        }

//        private static void GetAppointmentById(IHospitalService service)
//        {
//            Console.Write("Enter Appointment ID: ");
//            int id = int.Parse(Console.ReadLine());

//            try
//            {
//                Appointment appt = service.GetAppointmentById(id);
//                Console.WriteLine(appt);
//            }
//            catch (AppointmentNotFoundException ex)
//            {
//                Console.WriteLine("Error: " + ex.Message);
//            }
//        }

//        private static void GetAppointmentsForPatient(IHospitalService service)
//        {
//            Console.Write("Enter Patient ID: ");
//            int pid = int.Parse(Console.ReadLine());

//            List<Appointment> list = service.GetAppointmentsForPatient(pid);
//            foreach (var a in list)
//                Console.WriteLine(a);
//        }

//        private static void GetAppointmentsForDoctor(IHospitalService service)
//        {
//            Console.Write("Enter Doctor ID: ");
//            int did = int.Parse(Console.ReadLine());

//            List<Appointment> list = service.GetAppointmentsForDoctor(did);
//            foreach (var a in list)
//                Console.WriteLine(a);
//        }
//    }
//}

