﻿using System;

namespace HospitalManagementSystem.exception
{
    public class DoctorNotFoundException : ApplicationException
    {
        public DoctorNotFoundException() : base("Doctor not found.") { }

        public DoctorNotFoundException(string message) : base(message) { }
    }
}

