﻿using System;

namespace HospitalManagementSystem.exception
{
    public class AppointmentNotFoundException : ApplicationException
    {
        public AppointmentNotFoundException() : base("Appointment not found.") { }

        public AppointmentNotFoundException(string message) : base(message) { }
    }
}
