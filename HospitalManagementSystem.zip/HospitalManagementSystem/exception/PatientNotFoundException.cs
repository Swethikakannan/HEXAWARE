﻿using System;

namespace HospitalManagementSystem.exception
{
    public class PatientNotFoundException : ApplicationException
    {
        public PatientNotFoundException() : base("Patient not found.") { }

        public PatientNotFoundException(string message) : base(message) { }
    }
}
